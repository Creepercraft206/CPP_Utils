#ifndef _GUI_h_
#define _GUI_h_

#include "TGWMainWindow.h"

class TGWEdit;
class TGWBitmap;
class Bubbles;
class FileLogDevice;

class GUI : public TGWMainWindow
{
  TGWButton*     derTGWButton_1;
  TGWBitmap*     dieBitmap;
  
public:

  GUI();

  // ueberschriebene Methoden der Basisklasse
  void eventTimer(int id){};
  void eventButton(TGWButton* einButton, int event);
  void eventShow(){};
  void eventMouseClick(int posX, int posY, TGWindow* affectedWindow);
};

#endif
