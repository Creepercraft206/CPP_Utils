#include "GUI.h"

#include "TGWBitmap.h"
#include "TGWButton.h"
#include "UString.h"
#include "SystemAPI.h"
#include "TGWTimer.h"
#include "Log.h"
#include "FileLogDevice.h"
#include "ArrayList.h"

GUI::GUI()
  :TGWMainWindow(10, 10, 850, 650, "GUI Bubbles") //posX, posY, width, height, Caption, color
{
  derTGWButton_1  = new TGWButton(this, 10, 10, 120, 25, "Button 1" );
  ArrayList<int>* test = new ArrayList<int>();
}

void GUI::eventButton(TGWButton* einButton, int event)
{
  if ( einButton == derTGWButton_1 )
  {
  }  
}

void GUI::eventMouseClick(int posX, int posY, TGWindow* affectedWindow)
{
}
