#ifndef _LogFlags_h_
#define _LogFlags_h_

#define LF_D        0x0001  // Default, Wenn nichts angegeben wird
#define LF_EX       0x0002  // Enter Exit
#define LF_DF       0x0004  // DataFlow
#define LF_V        0x0008  // Verbose
#define LF_T        0x0010  // Timergesteuerte Ausgaben

#define LF_ALL      0xFFFF  // ALL

#endif
