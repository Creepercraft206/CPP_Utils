#ifndef _TGWindow_h_
#define _TGWindow_h_

/**
Ist fuer Grafik und Handles zustaendig
**/

#include <windows.h>

#include "TGWReflectionObject.h"
#include "UString.h"

class TGWMainWindow;

class TGWindow : public TGWReflectionObject
{
  friend TGWMainWindow;

public:
  HDC              myDeviceContext;

protected:
  static HINSTANCE myApplicationHandle;

  HWND             myWindowHandle;
  UString          captionBuffer; 
  HBRUSH           backgroundColorBrush;
  HBRUSH           paintBrush;
  HPEN             paintPen;
  int              backGroundColor;

  int posX;
  int posY;
  int width;
  int height;

  virtual void createCustomizedWindow()=0;

public:
  void createWindowSetWindowhandleAndCDC();

  TGWindow(TGWMainWindow* myParentWindow, UString className, int posX, int posY, int width, int height, UString caption="", int colorRRGGBB=0x888888);
  virtual ~TGWindow();

  UString getClassName()
  {
    return className;
  };

  static void messageBox(UString message, UString caption="Message");

  HWND getWindowHandle()
  {
    return myWindowHandle;
  };

  HDC getDeviceContext()
  {
    return myDeviceContext;
  };

  void setCaption(UString caption);
  UString getCaption();

  RECT getWindowRectangle();
  RECT getClientRectangle();
  RECT getChildRectange(TGWindow* child);

  int  getClientWidth();
  int  getClientHeight();
  int  getWidth();
  int  getHeight();

  void setWindowRectangle(int x1, int y1, int x2, int y2);
  void setWindowSize(int cx, int cy);
  void setWindowPos(int x1, int y1);
  bool checkOnArea(int posX, int posY);
  void toClientPos(int posX, int posY, int & cPosX, int & cPosY);

  int RGB_2_BGR(int col_RRGGBB);  //Color-Conversion

  void setPaintBrush(int colorRRGGBB);
  void setPaintPen  (int colorRRGGBB, int lineWidth=1);
  
  // The following in client-Coordinates:
  void paintRectangle(int x1, int y1, int x2, int y2);
  void paintEllipse(int x1, int y1, int x2, int y2);
  void moveTo(int x1, int y1);
  void lineTo(int x1, int y1);
  void invalidate(RECT invalidArea); 
  void invalidate(); //The whole clientrectangle
  void paint();
};

#endif
