#ifndef _TGWBitmap_h_
#define _TGWBitmap_h_

#include <windows.h>
#include "UString.h"

class TGWindow;

class TGWBitmap
{
public:
  TGWBitmap();
  virtual ~TGWBitmap();
  UString toString();

  HBITMAP   hBitmap;
  BITMAP    bitmapAttribute;
  TGWindow* lastTargetWindow;
  HDC       targetCompatibleContext;

  int getWidth()
  {
    if (hBitmap == 0) return 0;
    return bitmapAttribute.bmWidth;
  }

  int getHeight()
  {
    if (hBitmap == 0) return 0;
    return bitmapAttribute.bmHeight;
  }

  bool loadFileToBitmap(UString filename);  // Returns success

  void paintBitmap(TGWindow* target, int x , int y, bool resize=false, bool transparent=false, int tansparantColor = 0x000000);

  HBITMAP CreateBitmapMask(HBITMAP hbmColour, COLORREF crTransparent);
};

#endif