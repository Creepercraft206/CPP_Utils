#include "TGWindow.h"
#include "UString.h"
#include "TGWMainWindow.h"
#include "TGWButton.h"
#include "TGWReflectionObjectListe.h"

HINSTANCE TGWindow::myApplicationHandle = 0; // Wird in TGWMainWindow::registerWindowClass initialisiert

TGWindow::TGWindow(TGWMainWindow* myParentWindow, UString className, int posX, int posY, int width, int height, UString caption, int colorRRGGBB)
  :TGWReflectionObject(myParentWindow, className)
{
  myWindowHandle = 0; // wird in createWindowSetWindowhandleAndCDC initialisiert

  this->posX           = posX   ;
  this->posY           = posY   ;
  this->width          = width  ;
  this->height         = height ;
  this->captionBuffer  = caption;

  this->backgroundColorBrush = 0;
  this->paintPen             = 0;
  this->paintBrush           = 0;

  backGroundColor = colorRRGGBB;
}

TGWindow::~TGWindow()
{
  if (backgroundColorBrush!= 0) DeleteObject(backgroundColorBrush);
  if (paintBrush          != 0) DeleteObject(paintBrush          );
  ReleaseDC(myWindowHandle, myDeviceContext);
}

void TGWindow::createWindowSetWindowhandleAndCDC()
{
  createCustomizedWindow();

  if(myWindowHandle == 0)
  {
    messageBox("Window Creation Failed in TGWindow.cpp:196");
  }

  myDeviceContext = GetDC(myWindowHandle);
}

void TGWindow::messageBox(UString message, UString caption)
{
  MessageBox(0, message.c_str(), caption.c_str(), MB_ICONEXCLAMATION | MB_OK | MB_SYSTEMMODAL);
}

int TGWindow::RGB_2_BGR(int col_RRGGBB)
{
  return ((col_RRGGBB & 0x00FF0000)>>16) + (col_RRGGBB & 0x0000FF00) + ((col_RRGGBB & 0x000000FF)<<16);
}

RECT TGWindow::getWindowRectangle()
{
  RECT r;
  GetWindowRect(myWindowHandle, &r);
  return r;
}

RECT TGWindow::getClientRectangle()
{
  RECT r;
  GetClientRect(myWindowHandle, &r);
  return r;
}

RECT TGWindow::getChildRectange(TGWindow* child)
{
  RECT rect = child->getWindowRectangle();

  POINT p;
  POINT q;
  p.x = rect.left;
  p.y = rect.top;
  q.x = rect.right;
  q.y = rect.bottom;

  ScreenToClient(myWindowHandle, &p);
  ScreenToClient(myWindowHandle, &q);

  rect.left   = p.x;
  rect.top    = p.y;
  rect.right  = q.x;
  rect.bottom = q.y;

  return rect;
}

bool TGWindow::checkOnArea(int posX, int posY)
{
  if(this->posX        > posX) return false;
  if(this->posX+width  < posX) return false;
  if(this->posY        > posY) return false;
  if(this->posY+height < posY) return false;
  return true;
}

void TGWindow::toClientPos(int posX, int posY, int & cPosX, int & cPosY)
{
  cPosX = posX - this->posX;
  cPosY = posY - this->posY;
}


int TGWindow::getClientWidth()
{
  RECT r;
  GetClientRect(myWindowHandle, &r);
  return r.right-r.left;
}

int TGWindow::getClientHeight()
{
  RECT r;
  GetClientRect(myWindowHandle, &r);
  return r.bottom-r.top;   
}

int TGWindow::getWidth()
{
  RECT r;
  GetWindowRect(myWindowHandle, &r);
  return r.right-r.left;
}

int TGWindow::getHeight()
{
  RECT r;
  GetWindowRect(myWindowHandle, &r);
  return r.bottom-r.top;   
}

void TGWindow::setWindowRectangle(int x1, int y1, int x2, int y2)
{
  SetWindowPos(myWindowHandle,
               0,
               x1, y1, x2, y2,
               SWP_NOZORDER|SWP_NOACTIVATE);
  posX = x1;
  posY = y1;
  width  = x2-x1;
  height = y2-y1;
}

void TGWindow::setWindowPos(int x1, int y1)
{
  SetWindowPos(myWindowHandle,
               0,
               x1, y1, 0, 0,
               SWP_NOZORDER|SWP_NOACTIVATE|SWP_NOSIZE);
  posX = x1;
  posY = y1;
}

void TGWindow::setWindowSize(int cx, int cy)
{
  SetWindowPos(myWindowHandle,
               0,
               0, 0, cx, cy,
               SWP_NOZORDER|SWP_NOACTIVATE|SWP_NOMOVE);
  width  = cx;
  height = cy;
}

void TGWindow::invalidate(RECT invalidArea)
{
  InvalidateRect (myWindowHandle, &invalidArea, false);
}

void TGWindow::invalidate()
{
  InvalidateRect (myWindowHandle, 0, false);
}

void TGWindow::setCaption(UString caption)
{
  caption = caption.replace("\n", "\r\n");
  this->captionBuffer = caption;	
  SetWindowText(myWindowHandle, caption.c_str());
}

UString TGWindow::getCaption()
{
  int len = GetWindowTextLength(myWindowHandle);
  char* buf = new char[len+2];
  GetWindowText(myWindowHandle, buf, len+1);
  this->captionBuffer = buf;
  delete[] buf;
  return captionBuffer;
}

/*
int TGWindow::getBackgroundColor()
{
  return RGB_2_BGR(GetBkColor(myDeviceContext));
}
*/

// paint example
// https://msdn.microsoft.com/en-us/library/windows/desktop/dd145184(v=vs.85).aspx
// https://learn.microsoft.com/en-us/windows/win32/gdi/creating-colored-pens-and-brushes
// https://learn.microsoft.com/en-us/windows/win32/api/wingdi/nf-wingdi-ellipse
void TGWindow::paintRectangle(int x1, int y1, int x2, int y2)
{
  Rectangle(myDeviceContext, x1, y1, x2, y2);
}

void TGWindow::paintEllipse(int x1, int y1, int x2, int y2)
{
  Ellipse(myDeviceContext, x1, y1, x2, y2);
}

void TGWindow::setPaintBrush(int colorRRGGBB)
{
  if(paintBrush != 0) DeleteObject(paintBrush);
  paintBrush = CreateSolidBrush(RGB( (colorRRGGBB & 0xFF0000)>>16, (colorRRGGBB & 0xFF00)>>8, colorRRGGBB & 0xFF ) );
  SelectObject(myDeviceContext, paintBrush);
}

void TGWindow::setPaintPen(int colorRRGGBB, int lineWidth)
{
  if(paintPen != 0) DeleteObject(paintPen);
  paintPen = CreatePen(PS_SOLID, lineWidth, RGB( (colorRRGGBB & 0xFF0000)>>16, (colorRRGGBB & 0xFF00)>>8, colorRRGGBB & 0xFF ) );
  SelectObject(myDeviceContext, paintPen);
}

void TGWindow::lineTo(int x1, int y1)
{
  LineTo(myDeviceContext, x1, y1);
}

void TGWindow::moveTo(int x1, int y1)
{
  MoveToEx(myDeviceContext, x1, y1,0);
}

void TGWindow::paint()
{
  UpdateWindow(myWindowHandle);
}
