#include "TGWBitmap.h"
#include "TGWindow.h"

TGWBitmap::TGWBitmap()
{
  hBitmap                 = 0;
  lastTargetWindow        = 0;
  targetCompatibleContext = 0;
}

TGWBitmap::~TGWBitmap()
{
  if(hBitmap                 != 0) DeleteObject(hBitmap);
  if(targetCompatibleContext != 0) DeleteDC(targetCompatibleContext);

  hBitmap                 = 0;
  lastTargetWindow        = 0;
  targetCompatibleContext = 0;
}

UString TGWBitmap::toString()
{
  return "";
}

HBITMAP TGWBitmap::CreateBitmapMask(HBITMAP hbmColour, COLORREF crTransparent)
{
    HDC hdcMemBitmap; 
    HDC hdcMemMask;
    HBITMAP hbmMask;
    BITMAP  bm;

    // Create monochrome (1 bit) mask bitmap.  

    GetObject(hbmColour, sizeof(BITMAP), &bm);
    hbmMask = CreateBitmap(bm.bmWidth, bm.bmHeight, 1, 1, NULL);

    // Get some HDCs that are compatible with the display driver

    hdcMemBitmap = CreateCompatibleDC(0);
    hdcMemMask   = CreateCompatibleDC(0);

    SelectObject(hdcMemBitmap,  hbmColour);
    SelectObject(hdcMemMask,    hbmMask  );

    // Set the background colour of the colour image to the colour
    // you want to be transparent.
    SetBkColor(hdcMemBitmap, crTransparent);

    // Copy the bits from the colour image to the B+W mask... everything
    // with the background colour ends up white while everythig else ends up
    // black...Just what we wanted.

    BitBlt(hdcMemMask, 0, 0, bm.bmWidth, bm.bmHeight, hdcMemBitmap, 0, 0, SRCCOPY);

    // Take our new mask and use it to turn the transparent colour in our
    // original colour image to black so the transparency effect will
    // work right.
    BitBlt(hdcMemBitmap, 0, 0, bm.bmWidth, bm.bmHeight, hdcMemMask, 0, 0, SRCINVERT);

    // Clean up.

    DeleteDC(hdcMemBitmap);
    DeleteDC(hdcMemMask);

    return hbmMask;
}

bool TGWBitmap::loadFileToBitmap(UString filename)
{
  //https://cboard.cprogramming.com/windows-programming/63546-[cplusplus-winapi]-changing-bitmap-contrast.html
  hBitmap = (HBITMAP) LoadImage( NULL, filename.c_str(),  IMAGE_BITMAP, 0, 0, LR_LOADFROMFILE);

  if(!hBitmap) return false;
 
  GetObject(hBitmap, sizeof(bitmapAttribute), &bitmapAttribute); //bitmapAttribute fuellen

  return true;
}

void TGWBitmap::paintBitmap(TGWindow* targetWindow, int x , int y, bool resize, bool transparent, int tansparantColor)
{
  int cx =bitmapAttribute.bmWidth;
  int cy =bitmapAttribute.bmHeight;

  if(resize)
  {
    targetWindow->setWindowSize(cx, cy);
  }

  // So Nicht!
  //unsigned char firstBit = ((unsigned char*)bitmapAttribute.bmBits)[0];

  HDC targetContext = targetWindow->myDeviceContext;

  if(lastTargetWindow != targetWindow)
  {
    if(targetCompatibleContext != 0)
    {
      DeleteDC(targetCompatibleContext);
      targetCompatibleContext = 0;
    }

    lastTargetWindow = targetWindow;
    targetCompatibleContext = CreateCompatibleDC(targetContext);
  }

  if(transparent)
  { 
    HBITMAP hBitmapMask = CreateBitmapMask(hBitmap, tansparantColor);
    SelectObject(targetCompatibleContext, hBitmapMask);
    BitBlt(targetContext, x, y, cx, cy, targetCompatibleContext, 0, 0, SRCAND);

    SelectObject(targetCompatibleContext, hBitmap);
    BitBlt(targetContext, x, y, cx, cy, targetCompatibleContext, 0, 0, SRCPAINT);
  }
  else
  {
    SelectObject(targetCompatibleContext, hBitmap);
    BitBlt(targetContext, x, y, cx, cy, targetCompatibleContext, 0, 0, SRCCOPY);
  }
}
