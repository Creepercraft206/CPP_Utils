#ifndef _FileLogDevice_h
#define _FileLogDevice_h

#include "LogDevice.h"
#include "UString.h"

class FileLogDevice : public LogDevice
{
private:
  char* mFile;

public:
  FileLogDevice(const char* file);
public:
  ~FileLogDevice();

public:
  void     out(UString toLog);
};


#endif
